window.onload = function(){
    document.getElementById("demo").innerHTML = "Hello World";
}